#!/usr/bin/env python3
"""
CLX-AI Unit Tests
"""

import asyncio

import pytest
from clx import AutoLearningEngine, CLXCore, XLCSecurityMonitor


@pytest.fixture
def clx_instance():
    """Create a CLX instance for testing"""
    return CLXCore(memory_dir=".clx_test", enable_learning=False)


@pytest.mark.asyncio
async def test_clx_initialization(clx_instance):
    """Test CLX initialization"""
    assert clx_instance is not None
    assert clx_instance.learning is None  # Disabled in fixture
    assert clx_instance.security is not None
    assert clx_instance.knowledge is not None


@pytest.mark.asyncio
async def test_process_query(clx_instance):
    """Test basic query processing"""
    response = await clx_instance.process_query("Hello world")

    assert "response" in response
    assert "confidence" in response
    assert response["confidence"] >= 0.0


@pytest.mark.asyncio
async def test_learning_engine():
    """Test AutoLearningEngine"""
    engine = AutoLearningEngine(memory_dir=".clx_test_learning")

    # Process query
    result = engine.process_query("Hello")
    assert result["pattern_type"] == "greeting"

    # Learn something
    knowledge_id = await engine.learn_from_response(
        query="What is AI?",
        response="AI is artificial intelligence",
        sources=["test"],
        confidence=0.9,
    )
    assert knowledge_id is not None


def test_security_monitor():
    """Test XLC Security Monitor"""
    monitor = XLCSecurityMonitor(
        min_baseline_samples=2,
        block_deviation_ndb=100.0,
    )

    # Normal requests (building baseline)
    for i in range(3):
        result = monitor.evaluate(
            endpoint="/api/test",
            resonance_ndb=100.0,
            matched=True,
            route_name="test.route",
            input_text="test",
        )
        assert result is not None

    # Anomalous request (should trigger alert)
    result = monitor.evaluate(
        endpoint="/api/test",
        resonance_ndb=500.0,  # Way above baseline
        matched=False,
        route_name="test.route",
        input_text="attack",
    )

    assert result["attack_signature"]["detected"] == True
    assert result["firewall_action"]["action"] != "allow"


@pytest.mark.asyncio
async def test_knowledge_store(clx_instance):
    """Test knowledge store operations"""
    # Add knowledge
    kb_id = clx_instance.knowledge.add({
        "query": "Test query",
        "response": "Test response",
        "confidence": 0.95,
        "language": "en",
    })

    assert kb_id is not None

    # Retrieve knowledge
    kb = clx_instance.knowledge.get(kb_id)
    assert kb is not None
    assert kb["response"] == "Test response"

    # Verify stats
    stats = clx_instance.knowledge.get_stats()
    assert stats["total_entries"] > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
