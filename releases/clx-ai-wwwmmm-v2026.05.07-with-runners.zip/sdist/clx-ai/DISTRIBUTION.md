"""
PyPI Distribution Info — CLX-AI 0.01

This document explains how CLX-AI is distributed and what's included.

## Package Contents

- **clx/**: Core CLX-AI package
  - core.py: CLXCore main interface
  - engines/autolearning.py: Self-learning engine
  - security/monitor.py: XLC security runtime
  - knowledge/store.py: Knowledge persistence

- **examples/**: Working code examples

- **tests/**: Unit tests

- **documentation/**: Setup, build, and deployment guides

## Installation Methods

### From PyPI (Recommended)
```bash
pip install clx-ai
```

### From Source
```bash
git clone https://github.com/Web8kameleon-hub/clisonix.com
cd sdist/clx-ai
pip install -e .
```

### With FastAPI Support
```bash
pip install clx-ai[api]
```

### With Development Tools
```bash
pip install clx-ai[dev]
```

## Version History

- **0.01** (Current) — Initial release with:
  - Independent AI core
  - 4-hour self-learning
  - XLC security monitor
  - Multi-language support
  - Zero external ML dependencies

## Use Cases

1. **Lightweight AI**: Minimal footprint, no heavy models
2. **Edge Computing**: Deploy on resource-constrained systems
3. **Privacy-First**: No cloud APIs, local processing only
4. **Self-Improving**: Learns from user interactions
5. **Secure**: Built-in firewall and anomaly detection

## Distribution Channels

- PyPI: https://pypi.org/project/clx-ai/
- GitHub: https://github.com/Web8kameleon-hub/clisonix.com
- Direct: https://www.clisonix.com

## Support

- Issues: GitHub Issues
- Discussions: GitHub Discussions
- Email: ledjan@clisonix.com
- Website: https://www.clisonix.com

---

**CLX-AI 0.01** — The European AI platform that learns itself.
Made by ABA GMBH with ❤️ for developers worldwide.
"""
