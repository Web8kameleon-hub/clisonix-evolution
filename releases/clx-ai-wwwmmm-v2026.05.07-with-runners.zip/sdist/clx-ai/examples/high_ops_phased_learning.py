#!/usr/bin/env python3
"""
CLX-AI High Operations Phased Learning Runner.

This runner executes short, high-signal learning phases every tick (default: 10 min)
against local workspace materials, Git repositories, and live ecosystem endpoints.
Each cycle writes a compact stigma snapshot with real fingerprints from persisted memory.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import importlib.metadata
import json
import logging
import re
import subprocess
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from clx import CLXCore

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("clx-high-ops")

MANIFEST_GLOBS = [
    "**/requirements*.txt",
    "**/pyproject.toml",
    "**/package.json",
    "**/Cargo.toml",
]

CODE_GLOBS = [
    "**/*.py",
    "**/*.ts",
    "**/*.tsx",
    "**/*.js",
    "**/*.md",
]

DEFAULT_EXCLUDED_DIRS = {
    "node_modules",
    ".venv",
    "venv",
    "env",
    "env1",
    "env2",
    "env3",
    "__pycache__",
    ".git",
    "dist",
    "build",
    ".next",
    "target",
    ".pytest_cache",
    ".terraform",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _file_sha256(path: Path) -> Optional[str]:
    if not path.exists() or not path.is_file():
        return None
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 64), b""):
            h.update(chunk)
    return h.hexdigest()


def _list_files(
    workspace_root: Path,
    patterns: Iterable[str],
    excluded_dirs: set[str],
    max_files: int,
) -> List[Path]:
    files: List[Path] = []
    seen: set[str] = set()

    for pattern in patterns:
        for file_path in workspace_root.glob(pattern):
            if len(files) >= max_files:
                return files

            if not file_path.is_file():
                continue

            try:
                rel_path = file_path.relative_to(workspace_root)
            except ValueError:
                continue

            rel_parts = {part.lower() for part in rel_path.parts}
            if rel_parts & excluded_dirs:
                continue

            normalized = str(file_path.resolve()).lower()
            if normalized in seen:
                continue
            seen.add(normalized)
            files.append(file_path)

    return files


def _extract_code_signals(raw: str) -> Dict[str, Any]:
    lines = raw.splitlines()
    funcs = re.findall(r"^\s*def\s+([A-Za-z0-9_]+)\s*\(", raw, flags=re.MULTILINE)
    classes = re.findall(r"^\s*class\s+([A-Za-z0-9_]+)", raw, flags=re.MULTILINE)
    exports = re.findall(
        r"^\s*export\s+(?:async\s+)?(?:function|class|const)\s+([A-Za-z0-9_]+)",
        raw,
        flags=re.MULTILINE,
    )

    return {
        "line_count": len(lines),
        "function_count": len(funcs),
        "class_count": len(classes),
        "export_count": len(exports),
        "top_functions": funcs[:20],
        "top_classes": classes[:20],
        "top_exports": exports[:20],
    }


def _git_run(repo_path: Path, args: List[str], timeout: int = 8) -> Tuple[bool, str]:
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_path), *args],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except Exception as err:  # noqa: BLE001
        return False, str(err)

    if result.returncode != 0:
        return False, (result.stderr or result.stdout).strip()
    return True, result.stdout.strip()


def _discover_git_repos(workspace_root: Path, max_repos: int = 80) -> List[Path]:
    repos: List[Path] = []
    for git_dir in workspace_root.glob("**/.git"):
        if len(repos) >= max_repos:
            break
        try:
            rel_parts = {part.lower() for part in git_dir.parent.relative_to(workspace_root).parts}
        except ValueError:
            continue
        if rel_parts & DEFAULT_EXCLUDED_DIRS:
            continue
        if git_dir.is_dir():
            repos.append(git_dir.parent)
    return sorted(repos, key=lambda p: str(p).lower())


def _http_json(
    method: str,
    url: str,
    payload: Optional[Dict[str, Any]] = None,
    timeout: int = 10,
) -> Tuple[Optional[int], Optional[Dict[str, Any]], Optional[str]]:
    body = None
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json; charset=utf-8",
    }
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")

    request = Request(url=url, method=method.upper(), headers=headers, data=body)

    try:
        with urlopen(request, timeout=timeout) as response:
            status = int(getattr(response, "status", 200))
            raw = response.read().decode("utf-8", errors="replace").strip()
            if not raw:
                return status, None, None
            try:
                return status, json.loads(raw), None
            except json.JSONDecodeError:
                return status, None, f"non-json response: {raw[:240]}"
    except HTTPError as err:
        raw = err.read().decode("utf-8", errors="replace") if err.fp else ""
        return int(err.code), None, f"http_error: {raw[:240]}"
    except URLError as err:
        return None, None, f"url_error: {err}"
    except Exception as err:  # noqa: BLE001
        return None, None, f"unexpected_error: {err}"


def build_probe_catalog() -> List[Tuple[str, str, str, Optional[Dict[str, Any]]]]:
    bases = [
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8000",
        "https://www.clisonix.com",
        "https://api.clisonix.com",
    ]

    probes: List[Tuple[str, str, str, Optional[Dict[str, Any]]]] = []
    get_paths = [
        "/api/health",
        "/api/system/health",
        "/api/ocean/health",
        "/api/ocean/status",
        "/api/curiosity/health",
        "/api/auth/providers",
    ]
    for base in bases:
        for path in get_paths:
            probes.append(("GET", f"{base}{path}", f"probe:{path}", None))

    post_targets = [
        "http://127.0.0.1:3000/api/ocean/curiosity",
        "https://www.clisonix.com/api/ocean/curiosity",
    ]
    questions = [
        "What changed in this stack?",
        "Give current operation health summary.",
        "What are latest repo-level signals?",
    ]
    for target in post_targets:
        for q in questions:
            probes.append(("POST", target, f"curiosity:{q}", {"question": q}))

    return probes


async def _learn(
    clx: CLXCore,
    query: str,
    response_obj: Dict[str, Any],
    source: str,
    confidence: float,
    source_counter: Counter,
) -> None:
    response_text = json.dumps(response_obj, ensure_ascii=False)
    if not response_text.strip():
        return

    await clx.learning.learn_from_response(
        query=query,
        response=response_text,
        sources=[source],
        confidence=confidence,
        language="en",
    )
    clx.knowledge.add(
        {
            "query": query,
            "response": response_text,
            "confidence": confidence,
            "sources": [source],
            "language": "en",
        }
    )
    source_counter[source] += 1


def _load_state(state_path: Path) -> Dict[str, Any]:
    if not state_path.exists():
        return {
            "cycle_index": 0,
            "manifest_cursor": 0,
            "code_cursor": 0,
            "repo_cursor": 0,
        }
    try:
        return json.loads(state_path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {
            "cycle_index": 0,
            "manifest_cursor": 0,
            "code_cursor": 0,
            "repo_cursor": 0,
        }


def _save_state(state_path: Path, state: Dict[str, Any]) -> None:
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def _rotate_slice(items: List[Any], cursor: int, batch_size: int) -> Tuple[List[Any], int]:
    if not items:
        return [], 0
    start = cursor % len(items)
    out: List[Any] = []
    idx = start
    for _ in range(min(batch_size, len(items))):
        out.append(items[idx])
        idx = (idx + 1) % len(items)
    return out, idx


def _build_stigma(
    memory_dir_path: Path,
    source_counter: Counter,
    cycle_stats: Dict[str, Any],
) -> Dict[str, Any]:
    knowledge_path = memory_dir_path / "knowledge" / "knowledge.json"
    learning_path = memory_dir_path / "learning" / "knowledge.json"

    knowledge_entries = 0
    learning_entries = 0

    if knowledge_path.exists():
        try:
            knowledge_entries = len(json.loads(knowledge_path.read_text(encoding="utf-8")))
        except Exception:  # noqa: BLE001
            knowledge_entries = 0

    if learning_path.exists():
        try:
            learning_entries = len(json.loads(learning_path.read_text(encoding="utf-8")))
        except Exception:  # noqa: BLE001
            learning_entries = 0

    return {
        "root": str(memory_dir_path.name),
        "knowledge_entries": knowledge_entries,
        "learning_entries": learning_entries,
        "top_sources": source_counter.most_common(20),
        "knowledge_fingerprint": _file_sha256(knowledge_path),
        "learning_fingerprint": _file_sha256(learning_path),
        "cycle_stats": cycle_stats,
        "generated_at": utc_now(),
    }


async def phase_packages(clx: CLXCore, source_counter: Counter) -> Dict[str, int]:
    packages: List[Dict[str, str]] = []
    for dist in importlib.metadata.distributions():
        name = dist.metadata.get("Name") or dist.metadata.get("Summary") or "unknown"
        version = dist.version or "unknown"
        packages.append({"name": str(name), "version": str(version)})

    packages.sort(key=lambda item: item["name"].lower())
    payload = {
        "installed_packages": packages[:500],
        "package_count_total": len(packages),
    }
    await _learn(
        clx=clx,
        query="phase:packages:index",
        response_obj=payload,
        source="local:importlib.metadata",
        confidence=0.95,
        source_counter=source_counter,
    )
    return {"processed": len(payload["installed_packages"]), "learned": 1}


async def phase_manifests(
    clx: CLXCore,
    workspace_root: Path,
    manifest_files: List[Path],
    state: Dict[str, Any],
    source_counter: Counter,
    max_files: int,
    max_bytes_per_file: int,
) -> Dict[str, int]:
    batch, next_cursor = _rotate_slice(manifest_files, int(state.get("manifest_cursor", 0)), max_files)
    state["manifest_cursor"] = next_cursor

    learned = 0
    for file_path in batch:
        rel = str(file_path.relative_to(workspace_root)).replace("\\", "/")
        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")[:max_bytes_per_file].strip()
        except OSError:
            continue
        if not content:
            continue

        await _learn(
            clx=clx,
            query=f"phase:manifest:{rel}",
            response_obj={"path": rel, "content": content},
            source=f"local:{rel}",
            confidence=0.9,
            source_counter=source_counter,
        )
        learned += 1

    return {"processed": len(batch), "learned": learned}


async def phase_code_signals(
    clx: CLXCore,
    workspace_root: Path,
    code_files: List[Path],
    state: Dict[str, Any],
    source_counter: Counter,
    max_files: int,
    max_bytes_per_file: int,
) -> Dict[str, int]:
    batch, next_cursor = _rotate_slice(code_files, int(state.get("code_cursor", 0)), max_files)
    state["code_cursor"] = next_cursor

    learned = 0
    for file_path in batch:
        rel = str(file_path.relative_to(workspace_root)).replace("\\", "/")
        try:
            raw = file_path.read_text(encoding="utf-8", errors="replace")[:max_bytes_per_file]
        except OSError:
            continue

        if not raw.strip():
            continue

        signals = _extract_code_signals(raw)
        payload = {
            "path": rel,
            "sha256_chunk": hashlib.sha256(raw.encode("utf-8", errors="replace")).hexdigest(),
            "signals": signals,
        }
        await _learn(
            clx=clx,
            query=f"phase:code_signal:{rel}",
            response_obj=payload,
            source=f"code:{rel}",
            confidence=0.88,
            source_counter=source_counter,
        )
        learned += 1

    return {"processed": len(batch), "learned": learned}


async def phase_git_intel(
    clx: CLXCore,
    workspace_root: Path,
    repo_catalog: List[Path],
    state: Dict[str, Any],
    source_counter: Counter,
    max_repos: int,
) -> Dict[str, int]:
    batch, next_cursor = _rotate_slice(repo_catalog, int(state.get("repo_cursor", 0)), max_repos)
    state["repo_cursor"] = next_cursor

    learned = 0
    for repo in batch:
        rel = str(repo.relative_to(workspace_root)).replace("\\", "/")
        ok_head, head = _git_run(repo, ["rev-parse", "HEAD"])
        ok_branch, branch = _git_run(repo, ["rev-parse", "--abbrev-ref", "HEAD"])
        ok_log, log_out = _git_run(repo, ["log", "-n", "5", "--pretty=%h|%ct|%s"])

        payload = {
            "repo": rel,
            "head": head if ok_head else None,
            "branch": branch if ok_branch else None,
            "recent_commits": log_out.splitlines() if ok_log and log_out else [],
        }

        if payload["head"] is None and not payload["recent_commits"]:
            continue

        await _learn(
            clx=clx,
            query=f"phase:git:{rel}",
            response_obj=payload,
            source=f"git:{rel}",
            confidence=0.92,
            source_counter=source_counter,
        )
        learned += 1

    return {"processed": len(batch), "learned": learned}


async def phase_probes(
    clx: CLXCore,
    source_counter: Counter,
    max_probes: int,
) -> Dict[str, int]:
    probes = build_probe_catalog()[:max_probes]
    learned = 0
    errors = 0

    for method, url, query, payload in probes:
        status, data, err = await asyncio.to_thread(_http_json, method, url, payload, 10)
        if err or data is None:
            errors += 1
            continue

        confidence = 0.9 if (status is not None and 200 <= status < 300) else 0.3
        await _learn(
            clx=clx,
            query=query,
            response_obj=data,
            source=f"{method} {url}",
            confidence=confidence,
            source_counter=source_counter,
        )
        learned += 1

    return {"processed": len(probes), "learned": learned, "errors": errors}


async def run_high_ops(
    workspace_root: Path,
    memory_dir: str,
    report_file: str,
    state_file: str,
    tick_seconds: int,
    duration_seconds: int,
    enable_packages: bool,
    manifests_per_cycle: int,
    code_files_per_cycle: int,
    repos_per_cycle: int,
    probes_per_cycle: int,
) -> None:
    clx = CLXCore(memory_dir=memory_dir, language="en", enable_security=True, enable_learning=True)

    memory_dir_path = Path(memory_dir)
    state_path = Path(state_file)
    state = _load_state(state_path)
    source_counter: Counter = Counter()
    manifest_files = _list_files(
        workspace_root=workspace_root,
        patterns=MANIFEST_GLOBS,
        excluded_dirs=DEFAULT_EXCLUDED_DIRS,
        max_files=5000,
    )
    code_files = _list_files(
        workspace_root=workspace_root,
        patterns=CODE_GLOBS,
        excluded_dirs=DEFAULT_EXCLUDED_DIRS,
        max_files=12000,
    )
    repo_catalog = _discover_git_repos(workspace_root, max_repos=200)

    started_at = utc_now()
    start_ts = time.time()
    end_ts = start_ts + duration_seconds if duration_seconds > 0 else None

    logger.info(
        "high_ops_start tick_seconds=%s duration_seconds=%s manifests=%s code_files=%s repos=%s",
        tick_seconds,
        duration_seconds,
        len(manifest_files),
        len(code_files),
        len(repo_catalog),
    )

    while True:
        now_ts = time.time()
        if end_ts is not None and now_ts >= end_ts:
            break

        cycle_t0 = time.perf_counter()
        state["cycle_index"] = int(state.get("cycle_index", 0)) + 1
        cycle_index = int(state["cycle_index"])

        package_stats = {"processed": 0, "learned": 0}
        if enable_packages:
            package_stats = await phase_packages(clx, source_counter)

        manifest_stats = {"processed": 0, "learned": 0}
        if manifests_per_cycle > 0:
            manifest_stats = await phase_manifests(
                clx,
                workspace_root,
                manifest_files,
                state,
                source_counter,
                max_files=manifests_per_cycle,
                max_bytes_per_file=12000,
            )

        code_stats = {"processed": 0, "learned": 0}
        if code_files_per_cycle > 0:
            code_stats = await phase_code_signals(
                clx,
                workspace_root,
                code_files,
                state,
                source_counter,
                max_files=code_files_per_cycle,
                max_bytes_per_file=16000,
            )

        git_stats = {"processed": 0, "learned": 0}
        if repos_per_cycle > 0:
            git_stats = await phase_git_intel(
                clx,
                workspace_root,
                repo_catalog,
                state,
                source_counter,
                max_repos=repos_per_cycle,
            )

        probe_stats = {"processed": 0, "learned": 0, "errors": 0}
        if probes_per_cycle > 0:
            probe_stats = await phase_probes(clx, source_counter, max_probes=probes_per_cycle)

        cycle_elapsed = time.perf_counter() - cycle_t0
        status = clx.get_status()
        cycle_stats: Dict[str, Any] = {
            "cycle_index": cycle_index,
            "cycle_elapsed_seconds": round(cycle_elapsed, 3),
            "knowledge_entries": status.get("knowledge", {}).get("entries", 0),
            "packages": package_stats,
            "manifests": manifest_stats,
            "code_signals": code_stats,
            "git_intel": git_stats,
            "probes": probe_stats,
            "at": utc_now(),
        }

        stigma = _build_stigma(memory_dir_path=memory_dir_path, source_counter=source_counter, cycle_stats=cycle_stats)
        stigma_path = memory_dir_path / "stigma_memory.json"
        stigma_path.parent.mkdir(parents=True, exist_ok=True)
        stigma_path.write_text(json.dumps(stigma, ensure_ascii=False, indent=2), encoding="utf-8")

        report_payload = {
            "started_at": started_at,
            "last_cycle_at": utc_now(),
            "workspace_root": str(workspace_root),
            "memory_dir": memory_dir,
            "tick_seconds": tick_seconds,
            "duration_seconds": duration_seconds,
            "cycle_stats": cycle_stats,
            "top_sources": source_counter.most_common(30),
            "learning_stats": status.get("learning", {}).get("stats", {}),
        }
        report_path = Path(report_file)
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report_payload, ensure_ascii=False, indent=2), encoding="utf-8")

        _save_state(state_path, state)

        logger.info(
            "high_ops_cycle_complete cycle=%s entries=%s elapsed=%.2fs",
            cycle_index,
            cycle_stats["knowledge_entries"],
            cycle_elapsed,
        )

        if end_ts is not None and time.time() >= end_ts:
            break

        sleep_for = max(1, tick_seconds - int(cycle_elapsed))
        await asyncio.sleep(sleep_for)

    logger.info("high_ops_complete")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run CLX high-operations phased learning")
    parser.add_argument("--workspace-root", type=str, default=".")
    parser.add_argument("--memory-dir", type=str, default=".clx_ecosystem_highops")
    parser.add_argument("--report-file", type=str, default=".clx_ecosystem_highops/final_report.json")
    parser.add_argument("--state-file", type=str, default=".clx_ecosystem_highops/phased_state.json")
    parser.add_argument("--tick-seconds", type=int, default=600)
    parser.add_argument("--duration-seconds", type=int, default=0)
    parser.add_argument("--disable-packages", action="store_true")
    parser.add_argument("--manifests-per-cycle", type=int, default=60)
    parser.add_argument("--code-files-per-cycle", type=int, default=80)
    parser.add_argument("--repos-per-cycle", type=int, default=12)
    parser.add_argument("--probes-per-cycle", type=int, default=24)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    workspace_root = Path(args.workspace_root).resolve()
    asyncio.run(
        run_high_ops(
            workspace_root=workspace_root,
            memory_dir=args.memory_dir,
            report_file=args.report_file,
            state_file=args.state_file,
            tick_seconds=args.tick_seconds,
            duration_seconds=args.duration_seconds,
            enable_packages=not args.disable_packages,
            manifests_per_cycle=args.manifests_per_cycle,
            code_files_per_cycle=args.code_files_per_cycle,
            repos_per_cycle=args.repos_per_cycle,
            probes_per_cycle=args.probes_per_cycle,
        )
    )


if __name__ == "__main__":
    main()
