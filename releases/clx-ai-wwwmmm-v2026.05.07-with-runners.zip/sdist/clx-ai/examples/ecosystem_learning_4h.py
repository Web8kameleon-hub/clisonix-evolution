#!/usr/bin/env python3
"""
CLX-AI Ecosystem Learning Runner (4h)

Runs CLX learning against real Clisonix ecosystem endpoints.
No synthetic fallback responses are created: only successful real responses are learned.
"""

import argparse
import asyncio
import importlib.metadata
import json
import logging
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from clx import CLXCore

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("clx-ecosystem-learning")

MANIFEST_GLOBS = [
    "**/requirements*.txt",
    "**/pyproject.toml",
    "**/package.json",
    "**/Cargo.toml",
]

DEFAULT_EXCLUDED_DIRS = {
    "node_modules",
    ".venv",
    "venv",
    "env",
    "env1",
    "env2",
    "env3",
    "__pycache__",
    ".git",
    "dist",
    "build",
    ".next",
    "target",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def http_json(
    method: str,
    url: str,
    payload: Optional[Dict[str, Any]] = None,
    timeout: int = 10,
) -> Tuple[Optional[int], Optional[Dict[str, Any]], Optional[str]]:
    body = None
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json; charset=utf-8",
    }

    if payload is not None:
        body = json.dumps(payload).encode("utf-8")

    request = Request(url=url, method=method.upper(), headers=headers, data=body)

    try:
        with urlopen(request, timeout=timeout) as response:
            status = int(getattr(response, "status", 200))
            raw = response.read().decode("utf-8", errors="replace").strip()
            if not raw:
                return status, None, None
            try:
                return status, json.loads(raw), None
            except json.JSONDecodeError:
                return status, None, f"non-json response: {raw[:240]}"
    except HTTPError as err:
        raw = err.read().decode("utf-8", errors="replace") if err.fp else ""
        return int(err.code), None, f"http_error: {raw[:240]}"
    except URLError as err:
        return None, None, f"url_error: {err}"
    except Exception as err:  # noqa: BLE001
        return None, None, f"unexpected_error: {err}"


def build_probe_catalog() -> List[Tuple[str, str, str, Optional[Dict[str, Any]]]]:
    bases = [
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8000",
        "https://www.clisonix.com",
        "https://api.clisonix.com",
    ]

    probes: List[Tuple[str, str, str, Optional[Dict[str, Any]]]] = []

    get_paths = [
        "/api/health",
        "/api/system/health",
        "/api/ocean/health",
        "/api/ocean/status",
        "/api/curiosity/health",
        "/api/auth/providers",
    ]

    for base in bases:
        for path in get_paths:
            probes.append(("GET", f"{base}{path}", f"probe:{path}", None))

    post_targets = [
        "http://127.0.0.1:3000/api/ocean/curiosity",
        "https://www.clisonix.com/api/ocean/curiosity",
    ]
    questions = [
        "Cila eshte kryeqyteti i Shqiperise?",
        "What is CLX AI used for?",
        "Wie funktioniert Curiosity Ocean?",
    ]

    for target in post_targets:
        for q in questions:
            probes.append(("POST", target, f"curiosity:{q}", {"question": q}))

    return probes


def collect_installed_packages(limit: int = 400) -> List[Dict[str, str]]:
    packages: List[Dict[str, str]] = []

    for dist in importlib.metadata.distributions():
        name = dist.metadata.get("Name") or dist.metadata.get("Summary") or "unknown"
        version = dist.version or "unknown"
        packages.append({"name": str(name), "version": str(version)})

    packages.sort(key=lambda item: item["name"].lower())
    return packages[:limit]


def collect_local_manifests(
    workspace_root: Path,
    max_files: int = 200,
    max_bytes_per_file: int = 12000,
    excluded_dirs: Optional[set[str]] = None,
) -> List[Dict[str, str]]:
    manifests: List[Dict[str, str]] = []
    seen = set()
    excluded = excluded_dirs or DEFAULT_EXCLUDED_DIRS

    for pattern in MANIFEST_GLOBS:
        for file_path in workspace_root.glob(pattern):
            if len(manifests) >= max_files:
                return manifests

            if not file_path.is_file():
                continue

            try:
                rel_path = file_path.relative_to(workspace_root)
            except ValueError:
                continue

            rel_parts = {part.lower() for part in rel_path.parts}
            if rel_parts & excluded:
                continue

            normalized = str(file_path.resolve())
            if normalized in seen:
                continue
            seen.add(normalized)

            try:
                raw = file_path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            content = raw[:max_bytes_per_file].strip()
            if not content:
                continue

            manifests.append(
                {
                    "path": str(rel_path).replace("\\", "/"),
                    "content": content,
                }
            )

    return manifests


async def learn_local_ecosystem(
    clx: CLXCore,
    workspace_root: Path,
    source_counter: Counter,
    installed_limit: int = 400,
    manifest_limit: int = 200,
) -> int:
    learned = 0

    installed = collect_installed_packages(limit=installed_limit)
    if installed:
        response_text = json.dumps({"installed_packages": installed}, ensure_ascii=False)
        await clx.learning.learn_from_response(
            query="local_python_installed_packages",
            response=response_text,
            sources=["local:importlib.metadata"],
            confidence=0.95,
            language="en",
        )
        clx.knowledge.add(
            {
                "query": "local_python_installed_packages",
                "response": response_text,
                "confidence": 0.95,
                "sources": ["local:importlib.metadata"],
                "language": "en",
            }
        )
        source_counter["local:importlib.metadata"] += 1
        learned += 1

    manifests = collect_local_manifests(workspace_root, max_files=manifest_limit)
    for item in manifests:
        query = f"local_manifest:{item['path']}"
        response_text = item["content"]
        source = f"local:{item['path']}"
        await clx.learning.learn_from_response(
            query=query,
            response=response_text,
            sources=[source],
            confidence=0.9,
            language="en",
        )
        clx.knowledge.add(
            {
                "query": query,
                "response": response_text,
                "confidence": 0.9,
                "sources": [source],
                "language": "en",
            }
        )
        source_counter[source] += 1
        learned += 1

    return learned


async def run_ecosystem_learning(
    duration_seconds: int,
    interval_seconds: int,
    memory_dir: str,
    learn_local_packages: bool,
    workspace_root: Path,
    report_file: str,
) -> None:
    clx = CLXCore(memory_dir=memory_dir, language="en", enable_security=True, enable_learning=True)

    start = time.time()
    end = start + duration_seconds
    probes = build_probe_catalog()

    total_attempted = 0
    total_learned = 0
    total_errors = 0
    source_counter: Counter = Counter()
    started_at = utc_now()

    if learn_local_packages:
        local_learned = await learn_local_ecosystem(clx, workspace_root, source_counter)
        total_learned += local_learned
        logger.info("local_ecosystem_learning_complete learned=%s", local_learned)

    logger.info("Starting ecosystem learning")
    logger.info("duration_seconds=%s interval_seconds=%s probes_per_cycle=%s", duration_seconds, interval_seconds, len(probes))

    while time.time() < end:
        cycle_start = time.time()

        for method, url, query, payload in probes:
            total_attempted += 1
            status, data, err = await asyncio.to_thread(http_json, method, url, payload, 10)

            if err or data is None:
                total_errors += 1
                continue

            response_text = json.dumps(data, ensure_ascii=False)
            if not response_text.strip():
                continue

            confidence = 0.9 if (status is not None and 200 <= status < 300) else 0.3
            source = f"{method} {url}"

            await clx.learning.learn_from_response(
                query=query,
                response=response_text,
                sources=[source],
                confidence=confidence,
                language="en",
            )
            clx.knowledge.add(
                {
                    "query": query,
                    "response": response_text,
                    "confidence": confidence,
                    "sources": [source],
                    "language": "en",
                }
            )
            source_counter[source] += 1
            total_learned += 1

        status = clx.get_status()
        logger.info(
            "cycle_complete at=%s attempted=%s learned=%s errors=%s knowledge_entries=%s",
            utc_now(),
            total_attempted,
            total_learned,
            total_errors,
            status["knowledge"]["entries"],
        )

        elapsed_cycle = time.time() - cycle_start
        sleep_for = max(0, interval_seconds - int(elapsed_cycle))
        if sleep_for > 0 and time.time() < end:
            await asyncio.sleep(sleep_for)

    logger.info("Ecosystem learning complete")
    logger.info(
        "final_stats attempted=%s learned=%s errors=%s",
        total_attempted,
        total_learned,
        total_errors,
    )

    final_status = clx.get_status()
    report_path = Path(report_file)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_payload = {
        "started_at": started_at,
        "ended_at": utc_now(),
        "duration_seconds": duration_seconds,
        "workspace_root": str(workspace_root),
        "memory_dir": memory_dir,
        "learn_local_packages": learn_local_packages,
        "attempted": total_attempted,
        "learned": total_learned,
        "errors": total_errors,
        "knowledge_entries": final_status.get("knowledge", {}).get("entries", 0),
        "learning_stats": final_status.get("learning", {}).get("stats", {}),
        "top_sources": source_counter.most_common(20),
    }
    report_path.write_text(json.dumps(report_payload, ensure_ascii=False, indent=2), encoding="utf-8")
    logger.info("final_report_written path=%s", report_path)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run CLX ecosystem learning for 4h by default")
    parser.add_argument("--duration-seconds", type=int, default=4 * 3600)
    parser.add_argument("--interval-seconds", type=int, default=60)
    parser.add_argument("--memory-dir", type=str, default=".clx_ecosystem")
    parser.add_argument("--learn-local-packages", action="store_true")
    parser.add_argument("--workspace-root", type=str, default=".")
    parser.add_argument("--report-file", type=str, default=".clx_ecosystem/final_report.json")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    workspace_root = Path(args.workspace_root).resolve()
    asyncio.run(
        run_ecosystem_learning(
            duration_seconds=args.duration_seconds,
            interval_seconds=args.interval_seconds,
            memory_dir=args.memory_dir,
            learn_local_packages=args.learn_local_packages,
            workspace_root=workspace_root,
            report_file=args.report_file,
        )
    )


if __name__ == "__main__":
    main()
