#!/usr/bin/env python3
"""
Refresh a unified profile comparison report on a fixed interval.
"""

from __future__ import annotations

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_json(path: Path) -> Dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def build_profile_snapshot(name: str, root: Path) -> Dict[str, Any] | None:
    report = load_json(root / "final_report.json")
    stigma = load_json(root / "stigma_memory.json")
    if report is None or stigma is None:
        return None

    cycle = report.get("cycle_stats", {})
    processed_total = sum(
        int(cycle.get(section, {}).get("processed", 0))
        for section in ("packages", "manifests", "code_signals", "git_intel", "probes")
    )
    learned_total = sum(
        int(cycle.get(section, {}).get("learned", 0))
        for section in ("packages", "manifests", "code_signals", "git_intel", "probes")
    )
    elapsed = float(cycle.get("cycle_elapsed_seconds", 0) or 0)

    return {
        "profile": name,
        "memory_dir": str(root),
        "tick_seconds": int(report.get("tick_seconds", 0) or 0),
        "duration_seconds": int(report.get("duration_seconds", 0) or 0),
        "last_cycle_at": report.get("last_cycle_at"),
        "cycle_index": int(cycle.get("cycle_index", 0) or 0),
        "cycle_elapsed_seconds": elapsed,
        "knowledge_entries": int(cycle.get("knowledge_entries", 0) or 0),
        "learned_total_this_cycle": learned_total,
        "processed_total_this_cycle": processed_total,
        "cycle_efficiency": round(learned_total / processed_total, 4) if processed_total else None,
        "entry_density_per_second": round(int(cycle.get("knowledge_entries", 0) or 0) / elapsed, 3) if elapsed > 0 else None,
        "probe_errors": int(cycle.get("probes", {}).get("errors", 0) or 0),
        "knowledge_fingerprint": stigma.get("knowledge_fingerprint"),
        "learning_fingerprint": stigma.get("learning_fingerprint"),
        "top_sources": list(stigma.get("top_sources", []))[:10],
    }


def build_report(base_dir: Path, profile_names: List[str]) -> Dict[str, Any]:
    profiles: List[Dict[str, Any]] = []
    for name in profile_names:
        snapshot = build_profile_snapshot(name, base_dir / f".clx_ecosystem_{name}")
        if snapshot is not None:
            profiles.append(snapshot)

    leaderboard = sorted(
        [
            {
                "profile": item["profile"],
                "knowledge_entries": item["knowledge_entries"],
                "cycle_efficiency": item["cycle_efficiency"],
                "entry_density_per_second": item["entry_density_per_second"],
            }
            for item in profiles
        ],
        key=lambda item: item["knowledge_entries"],
        reverse=True,
    )

    return {
        "generated_at": utc_now(),
        "profiles": profiles,
        "leaderboard": leaderboard,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Refresh CLX profile comparison report")
    parser.add_argument("--base-dir", type=str, default=".")
    parser.add_argument("--output-file", type=str, default=".clx_profile_comparison.json")
    parser.add_argument("--interval-seconds", type=int, default=300)
    parser.add_argument("--profiles", nargs="*", default=["highops", "pressure", "aggressive", "load"])
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    base_dir = Path(args.base_dir).resolve()
    output_path = Path(args.output_file).resolve()

    while True:
        report = build_report(base_dir, args.profiles)
        output_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        time.sleep(max(1, args.interval_seconds))


if __name__ == "__main__":
    main()
