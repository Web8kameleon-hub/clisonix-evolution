#!/usr/bin/env python3
"""
Quick validation script for CLX-AI package
Verify all imports and basic functionality
"""

import sys
from pathlib import Path

# Add package to path
package_dir = Path(__file__).parent
sys.path.insert(0, str(package_dir))

def test_imports():
    """Test that all modules can be imported"""
    print("✅ Testing imports...\n")

    try:
        from clx import AutoLearningEngine, CLXCore, XLCSecurityMonitor
        print("  ✓ clx.__init__")
        print("  ✓ CLXCore")
        print("  ✓ AutoLearningEngine")
        print("  ✓ XLCSecurityMonitor")

        from clx.core import CLXCore
        print("  ✓ clx.core")

        from clx.engines.autolearning import AutoLearningEngine
        print("  ✓ clx.engines.autolearning")

        from clx.security.monitor import XLCSecurityMonitor
        print("  ✓ clx.security.monitor")

        from clx.knowledge.store import KnowledgeStore
        print("  ✓ clx.knowledge.store")

        return True
    except Exception as e:
        print(f"  ✗ Import failed: {e}")
        return False


def test_instantiation():
    """Test that core classes can be instantiated"""
    print("\n✅ Testing instantiation...\n")

    try:
        from clx import AutoLearningEngine, CLXCore, XLCSecurityMonitor

        # CLXCore
        clx = CLXCore(enable_learning=False)
        print("  ✓ CLXCore instantiated")

        # AutoLearningEngine
        engine = AutoLearningEngine(memory_dir="/tmp/.clx_test")
        print("  ✓ AutoLearningEngine instantiated")

        # XLCSecurityMonitor
        monitor = XLCSecurityMonitor()
        print("  ✓ XLCSecurityMonitor instantiated")

        return True
    except Exception as e:
        print(f"  ✗ Instantiation failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_basic_operations():
    """Test basic operations"""
    print("\n✅ Testing basic operations...\n")

    try:
        import asyncio

        from clx import CLXCore

        async def run_test():
            clx = CLXCore(enable_learning=False)

            # Process query
            response = await clx.process_query("Hello")
            assert response is not None
            assert "response" in response
            print("  ✓ Query processing works")

            # Get status
            status = clx.get_status()
            assert "version" in status
            print("  ✓ Status retrieval works")

            # Security monitoring
            result = clx.security.evaluate(
                endpoint="/api/test",
                resonance_ndb=100.0,
                matched=True,
                route_name="test",
                input_text="test"
            )
            assert result is not None
            print("  ✓ Security evaluation works")

            # Knowledge operations
            kb_id = clx.knowledge.add({
                "query": "Test",
                "response": "Test response",
                "confidence": 0.9,
            })
            assert kb_id is not None
            print("  ✓ Knowledge storage works")

        asyncio.run(run_test())
        return True
    except Exception as e:
        print(f"  ✗ Basic operations failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all validation tests"""
    print("\n" + "="*60)
    print("🔍 CLX-AI Package Validation")
    print("="*60)

    results = {
        "Imports": test_imports(),
        "Instantiation": test_instantiation(),
        "Basic Operations": test_basic_operations(),
    }

    print("\n" + "="*60)
    print("📊 Validation Results")
    print("="*60)

    passed = sum(1 for v in results.values() if v)
    total = len(results)

    for test_name, passed_flag in results.items():
        status = "✅ PASS" if passed_flag else "❌ FAIL"
        print(f"{status} — {test_name}")

    print(f"\nTotal: {passed}/{total} passed")

    if passed == total:
        print("\n✅ All validation tests passed!")
        print("   Package is ready for distribution.")
        return 0
    else:
        print("\n❌ Some validation tests failed.")
        print("   Please review the errors above.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
