#!/usr/bin/env python3
"""Compatibility shim for legacy tooling.

Project metadata lives in pyproject.toml.
"""

from setuptools import setup

setup()
