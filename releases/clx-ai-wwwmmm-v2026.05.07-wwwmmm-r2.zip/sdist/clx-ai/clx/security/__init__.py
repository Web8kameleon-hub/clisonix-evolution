"""Security module — XLC endpoint protection"""

from .monitor import XLCSecurityMonitor

__all__ = ["XLCSecurityMonitor"]
