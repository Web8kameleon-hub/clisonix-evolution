"""
XLC Security Monitor — Endpoint resonance and firewall
Provides ndB-based attack detection and security decisions
"""

import logging
import statistics
import time
from collections import Counter, deque
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class XLCSecurityMonitor:
    """Monitors endpoint resonance profiles and detects anomalies"""

    def __init__(
        self,
        min_baseline_samples: int = 5,
        max_baseline_samples: int = 120,
        alert_deviation_ndb: float = 500_000_000.0,
        block_deviation_ndb: float = 2_000_000_000.0,
    ):
        self.min_baseline_samples = max(3, int(min_baseline_samples))
        self.max_baseline_samples = max(self.min_baseline_samples, int(max_baseline_samples))
        self.alert_deviation_ndb = float(alert_deviation_ndb)
        self.block_deviation_ndb = float(block_deviation_ndb)
        self._profiles: Dict[str, Dict[str, Any]] = {}

        logger.info("✅ XLC Security Monitor initialized")

    def evaluate(
        self,
        *,
        endpoint: str,
        resonance_ndb: float,
        matched: bool,
        route_name: Optional[str],
        input_text: str,
    ) -> Dict[str, Any]:
        """Evaluate endpoint request for security"""
        profile = self._profiles.setdefault(
            endpoint,
            {
                "history": deque(maxlen=self.max_baseline_samples),
                "matched_history": deque(maxlen=self.max_baseline_samples),
                "route_counts": Counter(),
                "total_requests": 0,
                "last_seen": None,
            },
        )

        baseline = self._build_baseline(endpoint, profile)
        signature = self._detect_signature(
            endpoint=endpoint,
            profile=profile,
            baseline=baseline,
            resonance_ndb=float(resonance_ndb),
            matched=matched,
            route_name=route_name,
            input_text=input_text,
        )
        firewall_action = self._decide_firewall_action(signature)

        # Update profile
        profile["history"].append(float(resonance_ndb))
        profile["matched_history"].append(bool(matched))
        profile["route_counts"].update([route_name or "__unmatched__"])
        profile["total_requests"] += 1
        profile["last_seen"] = time.time()

        return {
            "resonance_profile": self._profile_snapshot(endpoint, profile),
            "normal_behavior_baseline": baseline,
            "attack_signature": signature,
            "firewall_action": firewall_action,
        }

    def get_profiles(self) -> List[Dict[str, Any]]:
        """Get all endpoint profiles"""
        return [
            self._profile_snapshot(endpoint, profile)
            for endpoint, profile in sorted(self._profiles.items())
        ]

    def get_profile(self, endpoint: str) -> Optional[Dict[str, Any]]:
        """Get specific endpoint profile"""
        profile = self._profiles.get(endpoint)
        return self._profile_snapshot(endpoint, profile) if profile else None

    def _build_baseline(self, endpoint: str, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Build baseline from collected samples"""
        history = list(profile["history"])

        if len(history) < self.min_baseline_samples:
            return {
                "armed": False,
                "samples": len(history),
                "mean_ndb": None,
                "median_ndb": None,
                "stdev_ndb": None,
            }

        mean = statistics.mean(history)
        median = statistics.median(history)
        stdev = statistics.stdev(history) if len(history) > 1 else 0.0

        return {
            "armed": True,
            "samples": len(history),
            "mean_ndb": round(mean, 2),
            "median_ndb": round(median, 2),
            "stdev_ndb": round(stdev, 2),
        }

    def _detect_signature(
        self,
        endpoint: str,
        profile: Dict[str, Any],
        baseline: Dict[str, Any],
        resonance_ndb: float,
        matched: bool,
        route_name: Optional[str],
        input_text: str,
    ) -> Dict[str, Any]:
        """Detect attack signatures"""
        signature = {
            "detected": False,
            "severity": "none",
            "indicators": [],
        }

        if not baseline.get("armed"):
            return signature

        # Check ndB deviation
        mean = baseline.get("mean_ndb", 0)
        stdev = baseline.get("stdev_ndb", 0)
        deviation = abs(resonance_ndb - mean)

        if deviation > self.block_deviation_ndb:
            signature["detected"] = True
            signature["severity"] = "critical"
            signature["indicators"].append(f"ndB deviation: {deviation:.0f}")
        elif deviation > self.alert_deviation_ndb:
            signature["detected"] = True
            signature["severity"] = "high"
            signature["indicators"].append(f"ndB deviation: {deviation:.0f}")

        # Check unmatched pattern
        matched_rate = sum(1 for m in profile["matched_history"] if m) / max(1, len(profile["matched_history"]))
        if not matched and matched_rate > 0.8:
            signature["detected"] = True
            if signature["severity"] != "critical":
                signature["severity"] = "medium"
            signature["indicators"].append("unmatched route")

        return signature

    def _decide_firewall_action(self, signature: Dict[str, Any]) -> Dict[str, Any]:
        """Decide firewall action based on signature"""
        severity = signature.get("severity", "none")

        if severity == "critical":
            return {"action": "block", "reason": "Critical anomaly detected"}
        elif severity == "high":
            return {"action": "throttle", "reason": "High anomaly detected", "rate_limit": 0.5}
        elif severity == "medium":
            return {"action": "monitor", "reason": "Medium anomaly detected"}
        else:
            return {"action": "allow", "reason": "Normal traffic"}

    def _profile_snapshot(self, endpoint: str, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Create endpoint profile snapshot"""
        return {
            "endpoint": endpoint,
            "total_requests": profile.get("total_requests", 0),
            "matched_rate": sum(1 for m in profile.get("matched_history", []) if m) / max(1, len(profile.get("matched_history", []))),
            "last_seen": profile.get("last_seen"),
            "dominant_route": profile.get("route_counts", {}).most_common(1)[0][0] if profile.get("route_counts") else None,
        }
