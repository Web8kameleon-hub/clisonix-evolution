#!/usr/bin/env python3
"""
CLXCore — Main Clisonix Intelligence Engine
Integrates autolearning, security, and knowledge management
"""

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .engines.autolearning import AutoLearningEngine
from .knowledge.store import KnowledgeStore
from .security.monitor import XLCSecurityMonitor

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("clx-core")


class CLXCore:
    """Clisonix independent AI core with integrated security and learning"""

    def __init__(
        self,
        memory_dir: str = ".clx/memory",
        language: str = "en",
        enable_security: bool = True,
        enable_learning: bool = True,
    ):
        """
        Initialize CLX Core

        Args:
            memory_dir: Path to persistent memory directory
            language: Default language (en, sq, de, it, fr, es, etc.)
            enable_security: Enable XLC security monitoring
            enable_learning: Enable continuous learning
        """
        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.language = language

        # Components
        self.learning = AutoLearningEngine(str(self.memory_dir / "learning")) if enable_learning else None
        self.security = XLCSecurityMonitor() if enable_security else None
        self.knowledge = KnowledgeStore(str(self.memory_dir / "knowledge"))

        # Status
        self.created_at = datetime.now(timezone.utc).isoformat()
        self.session_start = datetime.now(timezone.utc).isoformat()
        self.queries_processed = 0
        self.learning_active = False

        logger.info(f"✅ CLX Core initialized")
        logger.info(f"   📁 Memory: {self.memory_dir}")
        logger.info(f"   🧠 Learning: {'ENABLED' if self.learning else 'DISABLED'}")
        logger.info(f"   🔒 Security: {'ENABLED' if self.security else 'DISABLED'}")

    async def process_query(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Process a user query through CLX pipeline:
        1. Security check (if enabled)
        2. Pattern detection (via learning engine)
        3. Knowledge retrieval
        4. Response generation
        5. Learning update

        Args:
            query: User query
            context: Optional context (endpoint, source, language, etc.)

        Returns:
            Response dict with: response, confidence, sources, learned
        """
        self.queries_processed += 1
        timestamp = datetime.now(timezone.utc).isoformat()
        context = context or {}

        result = {
            "query": query,
            "timestamp": timestamp,
            "security_check": None,
            "pattern_match": None,
            "cached_response": None,
            "should_learn": True,
            "response": None,
            "confidence": 0.0,
            "sources": [],
        }

        try:
            # 1. Security check
            if self.security:
                endpoint = context.get("endpoint", "default")
                resonance = context.get("resonance_ndb", 0.0)
                security_result = self.security.evaluate(
                    endpoint=endpoint,
                    resonance_ndb=float(resonance),
                    matched=True,
                    route_name=context.get("route"),
                    input_text=query,
                )
                result["security_check"] = security_result

                # Block if firewall action is 'block'
                if security_result.get("firewall_action", {}).get("action") == "block":
                    logger.warning(f"🚫 Query blocked by XLC firewall: {query[:50]}")
                    result["response"] = "⚠️ Security policy violation. Request blocked."
                    result["confidence"] = 1.0
                    return result

            # 2. Pattern detection + cached knowledge
            if self.learning:
                pattern_result = self.learning.process_query(query)
                result["pattern_match"] = pattern_result.get("pattern_type")

                if pattern_result.get("pattern_response"):
                    result["cached_response"] = pattern_result["pattern_response"]
                    result["response"] = pattern_result["pattern_response"]
                    result["confidence"] = 0.95
                    result["should_learn"] = False
                    return result

                # Check knowledge cache
                if pattern_result.get("cached_knowledge"):
                    cached = pattern_result["cached_knowledge"]
                    result["cached_response"] = cached.get("response")
                    result["response"] = cached["response"]
                    result["confidence"] = cached.get("confidence", 0.8)
                    result["sources"] = [cached.get("knowledge_id")]
                    result["should_learn"] = False
                    return result

            # 3. Knowledge retrieval (fallback)
            kb_result = self.knowledge.search(query, limit=3)
            if kb_result:
                result["response"] = kb_result[0].get("content")
                result["confidence"] = kb_result[0].get("score", 0.7)
                result["sources"] = [kb_result[0].get("id")]
            else:
                result["response"] = "I don't have knowledge about this yet. Help me learn!"
                result["confidence"] = 0.1

            # 4. Learning update
            if result["should_learn"] and self.learning and result["response"]:
                knowledge_id = await self.learning.learn_from_response(
                    query=query,
                    response=result["response"],
                    sources=result.get("sources", []),
                    confidence=result["confidence"],
                    language=context.get("language", self.language),
                )
                self.knowledge.add({
                    "query": query,
                    "response": result["response"],
                    "confidence": result["confidence"],
                    "sources": result["sources"],
                    "language": context.get("language", self.language),
                })
                logger.info(f"🧠 Learned: {query[:50]}... → {knowledge_id}")

        except Exception as e:
            logger.error(f"❌ Error processing query: {e}")
            result["response"] = f"Error: {str(e)}"
            result["confidence"] = 0.0

        return result

    def get_status(self) -> Dict[str, Any]:
        """Get CLX core status"""
        learning_stats = {}
        if self.learning:
            learning_stats = self.learning.get_stats()

        security_stats = {}
        if self.security:
            security_stats = {
                "profiles_monitored": len(self.security.get_profiles()),
                "endpoints": [p["endpoint"] for p in self.security.get_profiles()],
            }

        return {
            "version": "0.01",
            "created_at": self.created_at,
            "session_start": self.session_start,
            "queries_processed": self.queries_processed,
            "learning": {
                "enabled": self.learning is not None,
                "active": self.learning_active,
                "stats": learning_stats,
            },
            "security": {
                "enabled": self.security is not None,
                **security_stats,
            },
            "knowledge": {
                "entries": len(self.knowledge.data),
                "languages": self.knowledge.get_stats().get("languages", []),
            },
        }

    async def start_learning(self, duration_seconds: int = 4 * 3600):
        """Start continuous learning (default 4 hours)"""
        if not self.learning:
            logger.warning("Learning engine not enabled")
            return

        self.learning_active = True
        logger.info(f"🧠 Learning started for {duration_seconds}s ({duration_seconds/3600:.1f}h)")
        await self.learning.run_learning_loop(duration_seconds)
        self.learning_active = False
        logger.info("✅ Learning session complete")

    def stop_learning(self):
        """Stop continuous learning"""
        self.learning_active = False
        if self.learning:
            self.learning.stop()
            logger.info("⏹️ Learning stopped")
