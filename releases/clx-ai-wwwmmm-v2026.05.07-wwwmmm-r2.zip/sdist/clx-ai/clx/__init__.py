"""
CLX-AI 0.01 — Clisonix Standalone Intelligence
A European AI platform with:
  • Self-learning engine (4-hour continuous learning)
  • XLC Security runtime (endpoint protection)
  • Multi-language support
  • Persistent knowledge base
  • Zero external dependencies for core AI
"""

__version__ = "0.01"
__author__ = "ABA GMBH — Ledjan Ahmati"
__copyright__ = "2025 Clisonix"

from .core import CLXCore
from .engines.autolearning import AutoLearningEngine
from .security.monitor import XLCSecurityMonitor

__all__ = [
    "CLXCore",
    "AutoLearningEngine",
    "XLCSecurityMonitor",
]
