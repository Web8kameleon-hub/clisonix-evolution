# CLX-AI 0.01 — README

## 🚀 Clisonix Independent AI — CLX

**The European AI that learns itself.**

A lightweight, standalone AI platform with integrated self-learning and security:
- **100% Independent**: No Ollama, no cloud APIs, no external dependencies
- **Self-Learning**: Continuous learning from queries (4-hour default)
- **Secure**: XLC security monitor with endpoint protection  
- **Multilingual**: Supports 14+ languages natively
- **European**: Made in Europe, by ABA GMBH

### 📦 Installation

```bash
pip install clx-ai
```

Or with FastAPI support:
```bash
pip install clx-ai[api]
```

### 🎯 Quick Start

```python
import asyncio
from clx import CLXCore

# Initialize CLX
clx = CLXCore(
    memory_dir=".clx",
    language="en",
    enable_security=True,
    enable_learning=True,
)

# Process a query
async def chat():
    response = await clx.process_query("What is AI?")
    print(response)

asyncio.run(chat())
```

### 🧠 Continuous Learning (4 Hours)

```python
# Start learning for 4 hours (or custom duration)
async def learn():
    await clx.start_learning(duration_seconds=4*3600)

asyncio.run(learn())
```

### 📊 Status & Stats

```python
status = clx.get_status()
print(status)
# {
#   "version": "0.01",
#   "queries_processed": 42,
#   "learning": {"enabled": True, "stats": {...}},
#   "security": {"enabled": True, "profiles_monitored": 5},
#   "knowledge": {"entries": 234, "languages": ["en", "sq", "de"]}
# }
```

### 🔒 Security Monitoring

XLC Security automatically:
- Monitors endpoint resonance profiles
- Detects traffic anomalies (ndB-based)
- Applies firewall actions (allow/monitor/throttle/block)
- Protects against pattern-based attacks

```python
# Check security profiles
profiles = clx.security.get_profiles()
# [
#   {
#     "endpoint": "/api/chat",
#     "total_requests": 1024,
#     "matched_rate": 0.98,
#     "dominant_route": "user.query"
#   }
# ]
```

### 💡 Examples

See `/examples` directory for:
- `basic_chat.py` — Simple query processing
- `learning_loop.py` — Continuous learning demo
- `security_monitoring.py` — Security profile verification
- `ecosystem_learning_4h.py` — 4h ecosystem learning against real endpoints
- `ecosystem_ops_10min.py` — high-operations phased learning every 10 minutes

### 📚 Knowledge Management

CLX automatically:
- Caches learned responses
- Detects query patterns
- Ranks knowledge by usefulness
- Persists to disk

```python
# Access knowledge directly
knowledge = clx.knowledge.search("Python", limit=5)
# [
#   {"id": "kb_abc123", "content": "...", "score": 0.95, "language": "en"},
#   ...
# ]
```

### 🌐 Supported Languages

- English, Albanian, German, Italian, French, Spanish
- Portuguese, Turkish, Finnish, Greek, Russian
- Arabic, Japanese, Chinese, Korean + more

### ⚙️ Configuration

```python
clx = CLXCore(
    memory_dir=".clx/custom",        # Custom memory directory
    language="sq",                   # Default language (Albanian)
    enable_security=True,            # Enable XLC security
    enable_learning=True,            # Enable self-learning
)
```

### 📈 Performance

- **Startup**: < 100ms
- **Query Processing**: ~10-50ms (cached) / ~100-500ms (new)
- **Memory Footprint**: ~50-100MB (with knowledge)
- **Learning Rate**: ~100-300 queries/hour

### 🔧 Development

```bash
# Clone the repo
git clone https://github.com/Web8kameleon-hub/clisonix.com

# Install with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest tests/

# Run linting
flake8 clx/
black clx/
```

### 📝 License

Apache 2.0 — See LICENSE file

### 🤝 Contributing

Contributions welcome! Open an issue or PR on GitHub.

### 📞 Support

- GitHub Issues: https://github.com/Web8kameleon-hub/clisonix.com/issues
- Email: ledjan@clisonix.com
- Website: https://www.clisonix.com

---

**Made by ABA GMBH with ❤️ for Europe**

*CLX — The AI that learns itself.*
